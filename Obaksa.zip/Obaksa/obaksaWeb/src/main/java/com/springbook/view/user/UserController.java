package com.springbook.view.user;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.springbook.biz.user.UserVO;
import com.springbook.biz.user.impl.UserDAO;

@Controller
@SessionAttributes("user")
public class UserController {
	@RequestMapping(value = "/login.do", method = RequestMethod.GET)
	public String loginView(UserVO vo) {
		System.out.println("로그인 화면으로 이동");
		vo.setId("kwj1270");
		vo.setPassword("rladnwo1270!");
		return "login.jsp";
	}

	@RequestMapping(value = "/login.do", method = RequestMethod.POST)
	public String login(UserVO vo, UserDAO userDAO, HttpSession session) {
		System.out.println("로그인 인증 처리...");
		if (vo.getId() == null || vo.getId().equals("")) {
			throw new IllegalArgumentException("아이디는 반드시 입력해야 합니다.");
		}

		UserVO user = userDAO.getUser(vo);
		if (user != null) {
			session.setAttribute("user", user);
			session.setAttribute("userName", user.getName());
			return "redirect:getBoardList.do";
		} else
			return "login.jsp";
	}
	
	@RequestMapping(value = "/logout.do")
	public String handleRequest(HttpSession session) {
		session.invalidate();
		return "redirect:login.do";
		}
	
	@RequestMapping(value = "/join.do", method = RequestMethod.GET)
	public String joinView(UserVO vo) {
		System.out.println("회원가입 화면으로 이동");
		return "join.jsp";
	}

	@RequestMapping(value = "/join.do", method = RequestMethod.POST)
	public String join(UserVO vo, UserDAO userDAO, HttpSession session) {
		if (vo.getId() == null || vo.getId().equals("")) {
			throw new IllegalArgumentException("아이디는 반드시 입력해야 합니다.");
		} else if (vo.getPassword() == null || vo.getPassword().equals("")) {
			throw new IllegalArgumentException("비밀번호는 반드시 입력해야 합니다.");
		} else if (vo.getName() == null || vo.getName().equals("")) {
			throw new IllegalArgumentException("이름은 반드시 입력해야 합니다.");
		}
		userDAO.insertUser(vo);
		UserVO user = userDAO.getUser(vo);
		if (user != null) {
			session.setAttribute("userName", user.getName());
			return "getBoardList.do";
		} else
			return "join.jsp";
	}
	
	@RequestMapping(value = "/editUser.do", method = RequestMethod.GET)
	public String editUserForm(UserVO vo) {
		System.out.println("회원 수정화면으로 이동");
		return "editUser.jsp";
	}

	@RequestMapping(value = "/editUser.do", method = RequestMethod.POST)
	public String editUser(UserVO vo, UserDAO userDAO, HttpSession session) {
		System.out.println("회원정보 수정 처리...");
		if (vo.getId() == null || vo.getId().equals("")) {
			throw new IllegalArgumentException("아이디는 반드시 입력해야 합니다.");
		} else if (vo.getPassword() == null || vo.getPassword().equals("")) {
			throw new IllegalArgumentException("비밀번호는 반드시 입력해야 합니다.");
		} else if (vo.getName() == null || vo.getName().equals("")) {
			throw new IllegalArgumentException("이름은 반드시 입력해야 합니다.");
		}
		userDAO.editUser(vo);
		UserVO user = userDAO.getUser(vo);
		if (user != null) {
			session.setAttribute("user", user);
			session.setAttribute("userName", user.getName());
			return "redirect:getBoardList.do";
		} else
			return "login.jsp";
	}
	
	@RequestMapping(value = "/idCheck.do", method = RequestMethod.GET)
	@ResponseBody
	public int idCheck(@RequestParam("id") String id, UserDAO userDAO) {
		System.out.println(id);
		int data = userDAO.userIdCheck(id);
		System.out.println(data);
		return data;
	}
	
	
}
