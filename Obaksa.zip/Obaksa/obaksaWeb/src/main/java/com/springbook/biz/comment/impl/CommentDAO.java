package com.springbook.biz.comment.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.springbook.biz.board.BoardVO;
import com.springbook.biz.comment.Comment;
import com.springbook.biz.common.JDBCUtil;
import com.springbook.biz.user.UserVO;

@Repository("commentDAO")
public class CommentDAO{
	// JDBC 관련 변수
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;

	private final String COMMENT_INSERT = "INSERT INTO comment(comment_seq, comment_board, comment_writer, comment_content) "
			+ "VALUES((SELECT ifnull(max(comment_seq),0)+1 FROM comment as c),?,?,?);"; // AUTOINCREMENT 기능 직접 추가
	// nvl(인자1, 인자2) 인자1이 null일 경우 인자2를 사용하겠다는 뜻
	private final String COMMENT_UPDATE = "UPDATE comment SET comment_content=? WHERE comment_seq=? AND comment_writer=?;";
	private final String COMMENT_DELETE = "DELETE FROM comment WHERE comment_seq=? AND comment_writer=?;";
	private final String COMMENT_GET = "SELECT * FROM comment WHERE comment_seq=? and comment_board=? and comment_writer=?;";
	private final String COMMENT_LIST = "SELECT * FROM comment WHERE comment_board=? ORDER BY comment_seq DESC;";
	
	
	
	public void insertComment(Comment comment , BoardVO vo, UserVO user) {
		System.out.println("===> JDBC로 insertComment() 기능 처리");
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(COMMENT_INSERT);
			System.out.println(vo.getSeq());
			System.out.println(user.getId());
			System.out.println(comment.getComment_content());
			pstmt.setInt(1, vo.getSeq());
			pstmt.setString(2, user.getId());
			pstmt.setString(3, comment.getComment_content());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt, conn);
		}
	}

	
	
	public void updateComment(Comment comment, UserVO user) {
		System.out.println("===> JDBC로 updateComment() 기능 처리");
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(COMMENT_UPDATE);
			pstmt.setString(1, comment.getComment_content());
			pstmt.setString(2, comment.getComment_content());
			pstmt.setString(3, user.getId());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt, conn);
		}
	}

	
	
	public void deleteComment(Comment comment, UserVO user) {
		System.out.println("===> JDBC로 deleteComment() 기능 처리");
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(COMMENT_DELETE);
			pstmt.setInt(1, comment.getComment_seq());
			pstmt.setString(2, user.getId());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt, conn);
		}
	}

	
	
	public Comment getComment(Comment comment, BoardVO vo, UserVO user) {
		System.out.println("===> JDBC로 getComment() 기능 처리");
		Comment comm = null;

		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(COMMENT_GET);
			pstmt.setInt(1, comment.getComment_seq());
			pstmt.setInt(2, vo.getSeq());
			pstmt.setString(3, user.getId());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				comm = new Comment();
				comm.setComment_seq(rs.getInt("comment_seq"));
				comm.setComment_board(rs.getInt("comment_board"));
				comm.setComment_writer(rs.getString("comment_writer"));
				comm.setComment_content(rs.getString("comment_content"));
				comm.setComment_regdate(rs.getDate("comment_regdate"));
				comm.setComment_available(rs.getInt("comment_available"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		return comm;
	}

	
	
	public List<Comment> getCommentList(BoardVO vo) {
		System.out.println("===> JDBC로 getBoardList()기능 처리");
		List<Comment> commentList = new ArrayList<Comment>();
		try {
			conn = JDBCUtil.getConnection();
			pstmt = conn.prepareStatement(COMMENT_LIST);
			System.out.println(vo.getSeq());
			pstmt.setInt(1, vo.getSeq());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Comment comm = new Comment();
				System.out.println(rs.getInt("comment_seq"));
				comm.setComment_seq(rs.getInt("comment_seq"));
				System.out.println(rs.getInt("comment_board"));
				comm.setComment_board(rs.getInt("comment_board"));
				System.out.println(rs.getString("comment_writer"));
				comm.setComment_writer(rs.getString("comment_writer"));
				System.out.println(rs.getString("comment_content"));
				comm.setComment_content(rs.getString("comment_content"));
				System.out.println(rs.getDate("comment_regdate"));
				comm.setComment_regdate(rs.getDate("comment_regdate"));
				System.out.println(rs.getInt("comment_available"));
				comm.setComment_available(rs.getInt("comment_available"));
				commentList.add(comm);
			}
		} catch (Exception e) {
			System.out.println("여긴가용ㅇ");
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, pstmt, conn);
		}
		System.out.println("결과가 어떤지 보자"+commentList.get(1).getComment_seq());
		return commentList;
	}	
}
