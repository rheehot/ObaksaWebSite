package com.springbook.biz.comment.impl;

import java.util.List;

import com.springbook.biz.board.BoardVO;
import com.springbook.biz.comment.Comment;
import com.springbook.biz.user.UserVO;

public interface ComSe {

	void insertComment(Comment comment, BoardVO vo, UserVO user);

	void updateComment(Comment comment, UserVO user);

	void deleteComment(Comment comment, UserVO user);

	Comment getComment(Comment comment, BoardVO vo, UserVO user);

	List<Comment> getCommentList(Comment comment, BoardVO vo);

}