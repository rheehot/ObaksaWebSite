package com.springbook.biz.comment.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbook.biz.board.BoardVO;
import com.springbook.biz.comment.Comment;
import com.springbook.biz.user.UserVO;

@Service("commentService")
public class CommentServiceImpl implements CommentService {

	@Autowired
	private CommentDAO commentDAO;

	@Override
	public void insertComment(Comment comment, BoardVO vo, UserVO user) {
		commentDAO.insertComment(comment, vo, user);
	}

	@Override
	public void updateComment(Comment comment, UserVO user) {
		commentDAO.updateComment(comment, user);
	}

	@Override
	public void deleteComment(Comment comment, UserVO user) {
		commentDAO.deleteComment(comment, user);

	}

	@Override
	public Comment getComment(Comment comment, BoardVO vo, UserVO user) {
		return commentDAO.getComment(comment, vo, user);
	}

	@Override
	public List<Comment> getCommentList( BoardVO vo) {
		return commentDAO.getCommentList( vo);

	}

}
