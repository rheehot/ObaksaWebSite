package kr.obaksa.www.biz.board.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import kr.obaksa.www.biz.board.Board;

@Repository
public class BoardDAOJPA {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public void insert(Board board) {
		entityManager.persist(board);
	}
	public void update(Board board) {
		entityManager.merge(board);
	}
	public void delete(Board board) {
		entityManager.remove(entityManager.find(Board.class, board));
	}
	public Board getBoard(Board board) {
		System.out.println("유저아이디 : " + board.getBoard_seq());
		return (Board)entityManager.find(Board.class, board.getBoard_seq());
	}
	public List<Board> getboardList(Board board) {
		return entityManager.createQuery("from Board b order by b.board_seq desc").getResultList();
	}
	public void incrementCnt(Board vo) {
		Board updateVO = getBoard(vo);
		updateVO.setBoard_cnt(updateVO.getBoard_cnt()+1);
		entityManager.merge(updateVO);
	}
}