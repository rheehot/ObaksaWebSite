package kr.obaksa.www.biz.board.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.obaksa.www.biz.board.Board;

@Service("boardService")
public class BoardServiceImpl implements BoardService {

	@Autowired
	BoardDAOJPA boardDAO;

	@Override
	public void insertBoard(Board board) {
		boardDAO.insert(board);
	}

	@Override
	public void updateBoard(Board board) {
		boardDAO.update(board);
	}

	@Override
	public void deleteBoard(Board board) {
		boardDAO.delete(board);
	}

	@Override
	public Board getBoard(Board board) {
		return boardDAO.getBoard(board);
	}

	@Override
	public List<Board> getBoardList(Board board) {
		return boardDAO.getboardList(board);
	}

}
