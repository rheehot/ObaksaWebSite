package kr.obaksa.www.views.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import kr.obaksa.www.biz.user.User;
import kr.obaksa.www.biz.user.impl.UserService;

@RestController
public class UserController {
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public ModelAndView loginPage(ModelAndView modelAndView) {
		System.out.println("로그인 페이지로 이동");
		modelAndView.setViewName("login");
		return modelAndView;
	}
	
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public ModelAndView login(User userVO, ModelAndView modelAndView) {
		System.out.println("로그인 인증 처리");
		User user = userService.getUser(userVO);
		if(user != null) {
			System.out.println("로그인 성공");
			modelAndView.addObject("member", user);
			modelAndView.setViewName("home");
		}else {
			System.out.println("로그인 실패");
			modelAndView.setViewName("login");
		}
		return modelAndView;
	}
	
	@RequestMapping(value="/join" , method = RequestMethod.GET)
	public ModelAndView joinPage(ModelAndView modelAndView) {
		System.out.println("회원가입 페이지로 이동");
		modelAndView.setViewName("join");
		return modelAndView;
	}
	
	@RequestMapping(value="/join", method = RequestMethod.POST)
	public ModelAndView join(User userVO, ModelAndView modelAndView) {
		System.out.println("회원가입 처리");
		User user = userService.getUser(userVO);
		if(user == null) {
			System.out.println("회원가입 성공");
			userService.insert(userVO);
			modelAndView.addObject("member", userVO);
			modelAndView.setViewName("home");
		}else {
			System.out.println("회원가입 실패");
			modelAndView.setViewName("join");
		}
		return modelAndView;
	}
	
	@RequestMapping(value="/join/check", method = RequestMethod.GET)
	public boolean joinCheck(User userVO) {
		User user = userService.getUser(userVO);
		boolean useOK = false;
		if(user == null) {
			System.out.println("아이디 사용 가능");
			useOK = true;
		}else {
			System.out.println("아이디 사용 불가능");
		}
		return useOK;
	}
	
}
