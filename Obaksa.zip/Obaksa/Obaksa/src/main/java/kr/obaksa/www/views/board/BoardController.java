package kr.obaksa.www.views.board;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.board.impl.BoardService;

@RestController
@SessionAttributes("board")
public class BoardController {
	@Autowired
	private BoardService boardservice;
	

	// 글 등록
	@RequestMapping(value = "/board/insert", method = RequestMethod.GET)
	public String boardPage(Board board) throws IOException{
		board.getBoard_seq()
		boardservice.insertBoard(board);
		return "board/"; // return "getBoardList.do";
	}

	// 글 수정
	@RequestMapping(value = "/updateBoard.do")
	public String updateBoard(@ModelAttribute("board") Board board) {
		System.out.println("번호 : " + board.getSeq());
		System.out.println("제목 : " + board.getTitle());
		System.out.println("작성자 : " + board.getWriter());
		System.out.println("내용 : " + board.getContent());
		System.out.println("등록일 : " + board.getRegDate());
		System.out.println("조회수 : " + board.getCnt());

		boardservice.updateBoard(board);
		return "getBoardList.do"; // return "getBoardList.do";
	}

	// 글 삭제
	@RequestMapping(value = "/deleteBoard.do")
	public String deleteBoard(Board board) {

		boardservice.deleteBoard(board);
		return "getBoardList.do";// return "getBoardList.do";
	}

	// 검색 조건 목록 설정
	@ModelAttribute("conditionMap")
	public Map<String, String> searchConditionMap() {
		Map<String, String> conditionMap = new HashMap<String, String>();
		conditionMap.put("제목", "TITLE");
		conditionMap.put("내용", "CONTENT");
		return conditionMap;
	}

	// 게시글 상세 조회
	@RequestMapping(value = "/getBoard.do")
	public String getBoard(Board board, Model model) {
		model.addAttribute("board", boardservice.getBoard(board));
		return "getBoard.jsp";
	}

	// 게시글 리스트
	@RequestMapping(value = "/getBoardList.do")
	public String getBoardList(Board board, Model model) {
		// Null Check
		if (board.getSearchCondition() == null) board.setSearchCondition("TITLE");
		if (board.getSearchKeyword() == null) board.setSearchKeyword("");
		// Model 정보 저장
		model.addAttribute("boardList", boardservice.getBoardList(board));
		return "getBoardList.jsp";
	}
}

}
