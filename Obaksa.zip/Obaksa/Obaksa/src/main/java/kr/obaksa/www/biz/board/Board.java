package kr.obaksa.www.biz.board;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "board")
public class Board implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int board_seq;
	@Column()
	private String board_title;
	@Column()
	private String board_writer;
	@Column()
	private String board_content;
	@Column()
	private Date board_regdate;
	@Column()
	private int board_cnt;
	@Column()
	private int board_available;
	
	/*
	@OneToMany(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "board_seq")
	private List<Comment> comment;
*/
	public Board() {
	}

	public Board(int board_seq, String board_title, String board_writer, String board_content, Date board_regdate,
			int board_file, int board_cnt, int board_available) {
		this.board_seq = board_seq;
		this.board_title = board_title;
		this.board_writer = board_writer;
		this.board_content = board_content;
		this.board_regdate = board_regdate;
		this.board_cnt = board_cnt;
		this.board_available = board_available;
	}

	public int getBoard_seq() {
		return board_seq;
	}

	public void setBoard_seq(int board_seq) {
		this.board_seq = board_seq;
	}

	public String getBoard_title() {
		return board_title;
	}

	public void setBoard_title(String board_title) {
		this.board_title = board_title;
	}

	public String getBoard_writer() {
		return board_writer;
	}

	public void setBoard_writer(String board_writer) {
		this.board_writer = board_writer;
	}

	public String getBoard_content() {
		return board_content;
	}

	public void setBoard_content(String board_content) {
		this.board_content = board_content;
	}

	public Date getBoard_regdate() {
		return board_regdate;
	}

	public void setBoard_regdate(Date board_regdate) {
		this.board_regdate = board_regdate;
	}

	public int getBoard_cnt() {
		return board_cnt;
	}

	public void setBoard_cnt(int board_cnt) {
		this.board_cnt = board_cnt;
	}

	public int getBoard_available() {
		return board_available;
	}

	public void setBoard_available(int board_available) {
		this.board_available = board_available;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
