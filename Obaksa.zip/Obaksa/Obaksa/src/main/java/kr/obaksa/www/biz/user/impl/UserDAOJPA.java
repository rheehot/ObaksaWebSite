package kr.obaksa.www.biz.user.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import kr.obaksa.www.biz.user.User;

@Repository
public class UserDAOJPA {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public void insert(User user) {
		entityManager.persist(user);
	}
	public void update(User user) {
		entityManager.merge(user);
	}
	public void delete(User user) {
		entityManager.remove(entityManager.find(User.class, user));
	}
	public User getUser(User user) {
		System.out.println("유저아이디 : " + user.getUser_id());
		return (User)entityManager.find(User.class, user.getUser_id());
	}
	public List<User> getUserList(User user) {
		return entityManager.createQuery("from User u order by u.user_id desc").getResultList();
	}

}
