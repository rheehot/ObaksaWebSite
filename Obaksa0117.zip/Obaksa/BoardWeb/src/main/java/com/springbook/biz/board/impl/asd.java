package com.springbook.biz.board.impl;

public class asd {

}
