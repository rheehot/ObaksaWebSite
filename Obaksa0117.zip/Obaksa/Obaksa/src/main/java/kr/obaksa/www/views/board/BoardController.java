package kr.obaksa.www.views.board;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.board.impl.BoardService;

@RestController
@SessionAttributes("board")
public class BoardController {
	@Autowired
	private BoardService boardservice;
	
	@RequestMapping(value = "/boards/board/{board_seq}")
	public ModelAndView getBoard(@PathVariable(value = "board_seq")int board_seq, Board board, ModelAndView modelAndView) {
		board = boardservice.getBoard(board);
		board.setBoard_cnt(board.getBoard_cnt()+1);
		boardservice.updateBoard(board);
		board = boardservice.getBoard(board);
		modelAndView.addObject("board", board);
		modelAndView.setViewName("board");
		return modelAndView;
	}

	@RequestMapping(value = "/boards")
	public ModelAndView getBoardList(Board board, ModelAndView modelAndView) {
		modelAndView.addObject("boardList", boardservice.getBoardList(board));
		modelAndView.setViewName("boards");
		return modelAndView;
	}
}

/*
// 湲� �벑濡�
@RequestMapping(value = "/board/insert", method = RequestMethod.GET)
public String boardPage(Board board) throws IOException{
	board.getBoard_seq();
	boardservice.insertBoard(board);
	return "board/"; // return "getBoardList.do";
}

// 湲� �닔�젙
@RequestMapping(value = "/updateBoard.do")
public String updateBoard(@ModelAttribute("board") Board board) {
	boardservice.updateBoard(board);
	return "getBoardList.do"; // return "getBoardList.do";
}

// 湲� �궘�젣
@RequestMapping(value = "/deleteBoard.do")
public String deleteBoard(Board board) {

	boardservice.deleteBoard(board);
	return "getBoardList.do";// return "getBoardList.do";
}

// 寃��깋 議곌굔 紐⑸줉 �꽕�젙
@ModelAttribute("conditionMap")
public Map<String, String> searchConditionMap() {
	Map<String, String> conditionMap = new HashMap<String, String>();
	conditionMap.put("�젣紐�", "TITLE");
	conditionMap.put("�궡�슜", "CONTENT");
	return conditionMap;
}
*/
