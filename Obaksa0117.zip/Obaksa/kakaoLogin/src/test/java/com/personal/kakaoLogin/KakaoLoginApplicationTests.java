package com.personal.kakaoLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KakaoLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
