package com.springbook.view.board;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.springbook.biz.board.BoardListVO;
import com.springbook.biz.board.BoardVO;
import com.springbook.biz.board.impl.BoardService;
import com.springbook.biz.comment.Comment;
import com.springbook.biz.comment.impl.CommentService;
import com.springbook.biz.user.UserVO;
import com.springbook.view.comment.CommentController;

@Controller
@SessionAttributes("board")
public class BoardController {
	@Autowired
	private BoardService boardservice;
	@Autowired
	private CommentService commentservice; // Imple을 가져옴  
	
	// 데이터 변환
	@RequestMapping(value="/dataTransform.do")
	@ResponseBody
	public BoardListVO dataTransform(BoardVO vo) {
		vo.setSearchCondition("TITLE");
		vo.setSearchKeyword("");
		List<BoardVO> boardList = boardservice.getBoardList(vo);
		BoardListVO boardListVO = new BoardListVO();
		boardListVO.setBoardList(boardList);
		return boardListVO;
	}
	
	// 글 등록
	@RequestMapping(value = "/insertBoard.do",method = RequestMethod.GET)
	public String InsertBoard(BoardVO vo, UserVO user) throws IOException{
		System.out.println("게시글 입력 화면으로 이돟");
		return "insertBoard.jsp"; // return "getBoardList.do";
	}
	
	// 글 등록
	@RequestMapping(value = "/insertBoard.do",method = RequestMethod.POST)
	public String Insert(BoardVO vo) throws IOException{
		// 파일 업로드 처리  
		MultipartFile uploadFile = vo.getUploadFile();
		if(!uploadFile.isEmpty()) {
			String fileName = uploadFile.getOriginalFilename();
			uploadFile.transferTo(new File("D:/" + fileName));
		}
		boardservice.insertBoard(vo);
		return "redirect:getBoardList.do"; // return "getBoardList.do";
	}
	// 글 수정
	@RequestMapping(value = "/updateBoard.do",method = RequestMethod.GET)
	public String updateBoard(@ModelAttribute("board") BoardVO vo) {
		return "updateBoard.jsp"; // return "getBoardList.do";
	}

	// 글 수정
	@RequestMapping(value = "/updateBoard.do",method = RequestMethod.POST)
	public String update(@ModelAttribute("board") BoardVO vo) {
		System.out.println("번호 : " + vo.getSeq());
		System.out.println("제목 : " + vo.getTitle());
		System.out.println("작성자 : " + vo.getWriter());
		System.out.println("내용 : " + vo.getContent());
		System.out.println("등록일 : " + vo.getRegDate());
		System.out.println("조회수 : " + vo.getCnt());
		boardservice.updateBoard(vo);
		return "getBoardList.do"; // return "getBoardList.do";
	}

	// 글 삭제
	@RequestMapping(value = "/deleteBoard.do")
	public String deleteBoard(BoardVO vo) {

		boardservice.deleteBoard(vo);
		return "getBoardList.do";// return "getBoardList.do";
	}

	// 검색 조건 목록 설정
	@ModelAttribute("conditionMap")
	public Map<String, String> searchConditionMap() {
		Map<String, String> conditionMap = new HashMap<String, String>();
		conditionMap.put("제목", "TITLE");
		conditionMap.put("내용", "CONTENT");
		return conditionMap;
	}
	public List<Comment> searchComment(BoardVO vo, HttpSession session) {
		List<Comment> commentList = commentservice.getCommentList(vo);
		session.setAttribute("commentList", commentList);
		return commentList;
	}
	// 게시글 상세 조회
	@RequestMapping(value = "/getBoard.do")
	public String getBoard(BoardVO vo, Model model, HttpServletRequest request ,HttpSession session) {
		vo.setSeq(Integer.parseInt(request.getParameter("seq")));
		searchComment(vo, session);
		model.addAttribute("board", boardservice.getBoard(vo));
		return "getBoard.jsp";
	}

	// 게시글 리스트
	@RequestMapping(value = "/getBoardList.do")
	public String getBoardList(BoardVO vo, Model model, HttpSession session) {
		if(session.getAttribute("user") == null) {
			return "login.do";
		}
		if (vo.getSearchCondition() == null) vo.setSearchCondition("TITLE");
		if (vo.getSearchKeyword() == null) vo.setSearchKeyword("");
		// Model 정보 저장
		model.addAttribute("boardList", boardservice.getBoardList(vo));
		return "getBoardList.jsp";
	}
	

}
