package com.springbook.view.comment;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.springbook.biz.board.BoardVO;
import com.springbook.biz.comment.Comment;
import com.springbook.biz.comment.impl.CommentService;
import com.springbook.biz.user.UserVO;

@Controller
public class CommentController {
	@Autowired
	private CommentService commentservice; // Imple을 가져옴  
	
	public List<Comment> searchComment(BoardVO vo, HttpSession session) {
		List<Comment> commentList = commentservice.getCommentList(vo);
		Comment comment = new Comment();
		if(commentList == null) {
			System.out.println("여기다");
			commentList.add(comment);
		}
		session.setAttribute("commentList", commentList);
		return commentList;
	}
	
	// 글 등록
	@RequestMapping(value = "/insertComment.do",method = RequestMethod.GET)
	public String InsertComment(BoardVO vo, UserVO user, Comment comment) throws IOException{
		return "redirect:getBoard.do?seq="+vo; 
	}
	// 글 등록
	@RequestMapping(value = "/insertComment.do",method = RequestMethod.POST)
	public String Insert(BoardVO vo, UserVO user, Comment comment, HttpSession session) throws IOException{
		vo.setWriter(user.getId());
		commentservice.insertComment(comment, vo, user);
		return "redirect:getBoard.do?seq="+vo.getSeq(); 
	}
	
	// 글 삭제
	@RequestMapping(value = "/deleteComment.do")
	public String deleteComment(Comment comment, UserVO user) {
		commentservice.deleteComment(comment, user);
		return "redirect:getBoard.do?seq="+comment.getComment_board();// return "getBoardList.do";
	}
	
}
