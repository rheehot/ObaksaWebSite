package com.springbook.biz.comment;

import java.sql.Date;

public class Comment {
	private int comment_seq;
	private int comment_board;
	private String comment_writer;
	private String comment_content;
	private Date comment_regdate;
	private int comment_available;
	
	public int getComment_seq() {
		return comment_seq;
	}
	public void setComment_seq(int comment_seq) {
		this.comment_seq = comment_seq;
	}
	public int getComment_board() {
		return comment_board;
	}
	public void setComment_board(int comment_board) {
		this.comment_board = comment_board;
	}
	public String getComment_content() {
		return comment_content;
	}
	public String getComment_writer() {
		return comment_writer;
	}
	public void setComment_writer(String comment_writer) {
		this.comment_writer = comment_writer;
	}
	public void setComment_content(String comment_content) {
		this.comment_content = comment_content;
	}
	public Date getComment_regdate() {
		return comment_regdate;
	}
	public void setComment_regdate(Date comment_regdate) {
		this.comment_regdate = comment_regdate;
	}
	public int getComment_available() {
		return comment_available;
	}
	public void setComment_available(int comment_available) {
		this.comment_available = comment_available;
	}
	
}
