$('.password2').change(function () {
	correctPassword($('.password').val(),$('.password2').val());
});

function correctPassword(password,password2){
    if (password != "" || password2 != "") {
        if (password == password2) {
            $("#alert-success").css('display', 'inline-block');
            $("#alert-danger").css('display', 'none');
        } else {
            $("#alert-success").css('display', 'none');
            $("#alert-danger").css('display', 'inline-block');
            $('.password2').val('').focus();
        }
    }
}

