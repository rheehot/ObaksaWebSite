package kr.obaksa.www.biz.cart.impl;

import java.util.List;

import kr.obaksa.www.biz.cart.Cart;

public interface CartService {

	void insertCart(Cart cart);

	void updateCart(Cart cart);

	void deleteCart(Cart cart);

	Cart getCart(Cart cart);

	List<Cart> getCartList(Cart cart);

	// 제품 상품 수량 변경
	void modifyCart(Cart cart);

	// 장바구니 금액 합계
	int getSumMoney(Cart cart);

	// 장바구니 동일한 상품 레코드 확인
	int getCartCount(Cart cart);

}