package kr.obaksa.www.biz.board.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.board.Criteria;

@Service("boardService")
public class BoardServiceImpl implements BoardService {

	@Autowired
	BoardDAOJPA boardDAOJPA;
	
	@Autowired
	BoardDAOMybatis boardDAOMybatis;
	

	@Override
	public void insertBoard(Board board) {
		boardDAOJPA.insert(board);
	}

	@Override
	public void updateBoard(Board board) {
		boardDAOJPA.update(board);
	}

	@Override
	public void deleteBoard(Board board) {
		boardDAOJPA.delete(board);
	}

	@Override
	public Board getBoard(Board board) {
		return boardDAOJPA.getBoard(board);
	}

	@Override
	public List<Board> getBoardList(Board board) {
		return boardDAOJPA.getboardList(board);
	}


	@Override
	public List<Board> listAll(Criteria cri) {
		return boardDAOMybatis.listAll(cri);
	}

	@Override
	public int getBoardCount() {
		return boardDAOMybatis.getBoardCount();
	}

}
