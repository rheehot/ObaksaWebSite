package kr.obaksa.www.biz.cart.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.obaksa.www.biz.cart.Cart;

@Service
public class CartServiceImpl implements CartService{
	
	@Autowired
	CartDAO cartDAO;
	
	@Override
	public void insertCart(Cart cart) {
		cartDAO.insertCart(cart);
	}

	@Override
	public void updateCart(Cart cart) {
		cartDAO.updateCart(cart);
	}

	@Override
	public void deleteCart(Cart cart) {
		cartDAO.deleteCart(cart);
	}

	@Override
	public Cart getCart(Cart cart) {
		return cartDAO.getCart(cart);
	}

	@Override
	public List<Cart> getCartList(Cart cart) {
		return cartDAO.getCartList(cart);
	}

	@Override
	public void modifyCart(Cart cart) {
		cartDAO.modifyCart(cart);
	}

	@Override
	public int getSumMoney(Cart cart) {
		return cartDAO.getSumMoney(cart);
	}

	@Override
	public int getCartCount(Cart cart) {
		return cartDAO.getCartCount(cart);
	}

}
