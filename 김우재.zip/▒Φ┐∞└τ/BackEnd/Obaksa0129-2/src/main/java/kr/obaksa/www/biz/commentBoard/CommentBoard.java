package kr.obaksa.www.biz.commentBoard;

import java.util.Date;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.comment.Comment;

public class CommentBoard {

	private int board_seq;
	private String board_title;
	private String board_writer;
	private String board_content;
	private Date board_regdate;
	private int board_cnt;
	private int board_available;
	private int comment_seq;
	private int comment_board;
	private String comment_writer;
	private String comment_content;
	private Date comment_regdate;
	private int comment_available;

	public CommentBoard() {
	}

	public CommentBoard(int board_seq) {
		this.board_seq = board_seq;
	}

	public CommentBoard(int board_seq, String board_title, String board_writer, String board_content,
			Date board_regdate, int board_cnt, int board_available, int comment_seq, int comment_board,
			String comment_writer, String comment_content, Date comment_regdate, int comment_available) {
		this.board_seq = board_seq;
		this.board_title = board_title;
		this.board_writer = board_writer;
		this.board_content = board_content;
		this.board_regdate = board_regdate;
		this.board_cnt = board_cnt;
		this.board_available = board_available;
		this.comment_seq = comment_seq;
		this.comment_board = comment_board;
		this.comment_writer = comment_writer;
		this.comment_content = comment_content;
		this.comment_regdate = comment_regdate;
		this.comment_available = comment_available;
	}

	public int getBoard_seq() {
		return board_seq;
	}

	public void setBoard_seq(int board_seq) {
		this.board_seq = board_seq;
	}

	public String getBoard_title() {
		return board_title;
	}

	public void setBoard_title(String board_title) {
		this.board_title = board_title;
	}

	public String getBoard_writer() {
		return board_writer;
	}

	public void setBoard_writer(String board_writer) {
		this.board_writer = board_writer;
	}

	public String getBoard_content() {
		return board_content;
	}

	public void setBoard_content(String board_content) {
		this.board_content = board_content;
	}

	public Date getBoard_regdate() {
		return board_regdate;
	}

	public void setBoard_regdate(Date board_regdate) {
		this.board_regdate = board_regdate;
	}

	public int getBoard_cnt() {
		return board_cnt;
	}

	public void setBoard_cnt(int board_cnt) {
		this.board_cnt = board_cnt;
	}

	public int getBoard_available() {
		return board_available;
	}

	public void setBoard_available(int board_available) {
		this.board_available = board_available;
	}

	public int getComment_seq() {
		return comment_seq;
	}

	public void setComment_seq(int comment_seq) {
		this.comment_seq = comment_seq;
	}

	public int getComment_board() {
		return comment_board;
	}

	public void setComment_board(int comment_board) {
		this.comment_board = comment_board;
	}

	public String getComment_writer() {
		return comment_writer;
	}

	public void setComment_writer(String comment_writer) {
		this.comment_writer = comment_writer;
	}

	public String getComment_content() {
		return comment_content;
	}

	public void setComment_content(String comment_content) {
		this.comment_content = comment_content;
	}

	public Date getComment_regdate() {
		return comment_regdate;
	}

	public void setComment_regdate(Date comment_regdate) {
		this.comment_regdate = comment_regdate;
	}

	public int getComment_available() {
		return comment_available;
	}

	public void setComment_available(int comment_available) {
		this.comment_available = comment_available;
	}

}
