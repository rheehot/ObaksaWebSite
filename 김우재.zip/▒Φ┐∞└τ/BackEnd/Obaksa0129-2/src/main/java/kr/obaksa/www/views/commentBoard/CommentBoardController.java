package kr.obaksa.www.views.commentBoard;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.commentBoard.CommentBoard;
import kr.obaksa.www.biz.commentBoard.impl.CommentBoardService;

@RestController
public class CommentBoardController {
	
	@Autowired
	@Qualifier("commentBoardServiceMybatis")
	private CommentBoardService commentBoardserviceMybatis;
	
	@RequestMapping(value = "boards/{board_seq}/commentList")
	public ModelAndView getCommentList(@PathVariable(value = "board_seq") int board_seq, Board board, ModelAndView modelAndView) {
		CommentBoard commentBoard = new CommentBoard(board.getBoard_seq());
		List<CommentBoard> commentList = commentBoardserviceMybatis.getCommentBoardList(commentBoard);
		modelAndView.addObject("commentList", commentList);
		modelAndView.setViewName("boards/"+board_seq);
		return modelAndView;
	}
	
	@RequestMapping(value = "boards/{board_seq}/commentList/JSON")
	public List<CommentBoard> getCommentListJSON(@PathVariable(value = "board_seq") int board_seq, Board board, ModelAndView modelAndView) {
		System.out.println(board.getBoard_seq());
		CommentBoard commentBoard = new CommentBoard(board.getBoard_seq());
		List<CommentBoard> commentList = commentBoardserviceMybatis.getCommentBoardList(commentBoard);
		System.out.println("여기까지 왔으면 좋겠어");
		return commentList;
	}
	

	@RequestMapping(value = "boards/{board_seq}/commentCount")
	public int getBoardListCount(@PathVariable(value = "board_seq") int board_seq , Board board, Model model) {
		CommentBoard commentBoard = new CommentBoard(board.getBoard_seq());
		int count = commentBoardserviceMybatis.getCommentBoardCount(commentBoard);
		return count;
	}
}

/*
 * 	@RequestMapping(value = "boards/{board_seq}/commentList")
	public Model getBoardList(@PathVariable(value = "board_seq") int board_seq, Board board, Model model) {
		CommentBoard commentBoard = new CommentBoard(board.getBoard_seq());
		model.addAttribute("commentBoardList", commentBoardserviceMybatis.getCommentBoardList(commentBoard));
		return model;
	}
 * 
 * */
 