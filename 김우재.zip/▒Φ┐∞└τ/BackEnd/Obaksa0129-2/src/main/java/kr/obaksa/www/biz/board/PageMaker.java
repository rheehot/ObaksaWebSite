package kr.obaksa.www.biz.board;

public class PageMaker {

	private Criteria cri; // 현재 페이지와 보여줄 갯수 지정
	private int totalCount; // 전페 페이지 갯수
	private int firstPage; // 맨 처음 페이지
	private int startPage; // 블록 시작 페이지
	private int endPage; // 블록 끝 페이지
	private int lastPage; // 맨 마지막  페이지
	private boolean prev; // 이전 페이지
	private boolean next; // 다음 페이지
	private int displayPageNum = 5; // 페이지 번호의 갯수 즉 블록당 페이지 몇개 보여줄거냐 (화면 하단의 페이지 버튼의 수)

	public PageMaker() {
	}

	public PageMaker(Criteria cri) {
		this.cri = cri;
	}

	public Criteria getCri() {
		return cri;
	}

	public void setCri(Criteria cri) {
		this.cri = cri;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
		calcData();
	}

	private void calcData() {

		// cri.getPage()는 현재 페이지 번호

		// 블록에서 보여줄 끝 페이지 설정
		// 현재 페이지가 5미만이여도 블록당 보여줄 페이지를 나타내야 하므로 0.몇몇 을 1로 치환후 다시 곱해서 5개의 페이지 범위를 얻는다.
		System.out.println(cri.getPage());
		endPage = (int) (Math.ceil(cri.getPage() / (double) displayPageNum) * displayPageNum);

		// 블록에서 시작할 페이지를 정한다.
		// 혹시모르게 시작 페이지가 0이 될 수 있으니 이를 방지하고 0이하 일 경우 1로 만들어 주었다.
		startPage = (endPage - displayPageNum) + 1;
		if (startPage <= 0) {
			startPage = 1;
		}

		// 현재페이지 / 페이지당 보여줄 게시글 -> 현재 페이지가
		// 게시글 갯수가 적으면 블록에 보여줄 endPage 갯수도 기존 보다 작게 표시 되어야 하는데 이를 위한 작업
		int tempEndPage = (int) (Math.ceil(totalCount / (double) cri.getPerPageNum()));
		
		if (endPage > tempEndPage) {
			endPage = tempEndPage;
		}
		prev = startPage == 1 ? false : true;
		next = endPage * cri.getPerPageNum() < totalCount ? true : false;

		///////////////////////////////////////////////////////////////////////
		firstPage = 1;
		lastPage = tempEndPage;
	}

	public int getStartPage() {
		return startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getFirstPage() {
		return firstPage;
	}

	public void setFirstPage(int firstPage) {
		this.firstPage = firstPage;
	}
	
	public int getLastPage() {
		return lastPage;
	}

	public void setLastPage(int lastPage) {
		this.lastPage = lastPage;
	}

	public int getEndPage() {
		return endPage;
	}

	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}

	public boolean isPrev() {
		return prev;
	}

	public void setPrev(boolean prev) {
		this.prev = prev;
	}

	public boolean isNext() {
		return next;
	}

	public void setNext(boolean next) {
		this.next = next;
	}

	public int getDisplayPageNum() {
		return displayPageNum;
	}

	public void setDisplayPageNum(int displayPageNum) {
		this.displayPageNum = displayPageNum;
	}

}