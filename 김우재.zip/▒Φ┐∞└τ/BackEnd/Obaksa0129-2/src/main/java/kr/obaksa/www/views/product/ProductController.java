package kr.obaksa.www.views.product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import kr.obaksa.www.biz.product.Product;
import kr.obaksa.www.biz.product.impl.ProductService;

@RestController
@SessionAttributes("product")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@RequestMapping("/products")
	public ModelAndView productList(ModelAndView modelAndView, Product product) {
		modelAndView.setViewName("/products");
		modelAndView.addObject("productList", productService.getProductList(product));
		return modelAndView;
	}
	
	@RequestMapping("/products/{product_id}")
	public ModelAndView productDetail(@PathVariable(value = "product_id") int product_id,ModelAndView modelAndView, Product product) {
		product.setProduct_id(product_id);
		modelAndView.addObject("product", productService.getProduct(product));
		modelAndView.setViewName("/products/product");
		return modelAndView;
	}	
	
}
