package kr.obaksa.www.biz.board.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.board.Criteria;

@Service("boardServiceMybatis")
public class BoardServiceImplMybatis implements BoardService {

	@Autowired
	private BoardDAOMybatis boardDAO;

	public void insertBoard(Board vo) {
		boardDAO.insertBoard(vo); 
	}

	public void updateBoard(Board vo) {
		boardDAO.updateBoard(vo);
	}

	public void deleteBoard(Board vo) {
		boardDAO.deleteBoard(vo);
	}

	public Board getBoard(Board vo) {
		return boardDAO.getBoard(vo);
	}

	public List<Board> getBoardList(Board vo) {
		return boardDAO.getBoardList(vo);
	}

	@Override
	public List<Board> listAll(Criteria cri) {
		return boardDAO.listAll(cri);
	}

	@Override
	public int getBoardCount() {
		return boardDAO.getBoardCount();
	}


}
