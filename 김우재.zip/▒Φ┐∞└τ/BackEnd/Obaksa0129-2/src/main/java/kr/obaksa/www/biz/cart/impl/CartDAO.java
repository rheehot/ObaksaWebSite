package kr.obaksa.www.biz.cart.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.obaksa.www.biz.cart.Cart;

@Repository
public class CartDAO {

	@Autowired
	SqlSessionTemplate mybatis;

	public void insertCart(Cart cart) {
		System.out.println("===> Mybatis로 insertCart() 기능처리");
		mybatis.insert("CartDAO.insertCart", cart);
	}

	public void updateCart(Cart cart) {
		System.out.println("===> Mybatis로 updateCart() 기능처리");
		mybatis.update("CartDAO.updateCart", cart);
	}

	public void deleteCart(Cart cart) {
		System.out.println("===> Mybatis로 deleteCart() 기능처리");
		mybatis.delete("CartDAO.deleteCart", cart);
	}

	public Cart getCart(Cart cart) {
		System.out.println("===> Mybatis로 getCart() 기능처리");
		return (Cart) mybatis.selectOne("CartDAO.getCart", cart);
	}

	public List<Cart> getCartList(Cart cart) {
		System.out.println("===> Mybatis로 getCartList() 기능처리");
		return mybatis.selectList("CartDAO.getCartList", cart);
	}

	// 제품 상품 수량 변경
	public void modifyCart(Cart cart) {
		System.out.println("===> Mybatis로 modifyCart() 기능처리");
		mybatis.update("CartDAO.modifyCart", cart);
	}

	// 장바구니 금액 합계
	public int getSumMoney(Cart cart) {
		System.out.println("===> Mybatis로 getSumMoney() 기능처리");
		return mybatis.selectOne("CartDAO.getSumMoney", cart);
	}

	// 장바구니 동일한 상품 레코드 확인
	public int getCartCount(Cart cart) {
		System.out.println("===> Mybatis로 getCartCount() 기능처리");
		return mybatis.selectOne("CartDAO.getCartCount", cart);
	}
}
