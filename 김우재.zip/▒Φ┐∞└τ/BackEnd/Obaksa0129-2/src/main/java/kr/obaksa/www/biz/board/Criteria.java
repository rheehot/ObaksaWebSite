package kr.obaksa.www.biz.board;

public class Criteria {
	private int page; // 현재 페이지 번호
	private int perPageNum; // 페이지당 보여줄 게시글의 갯수
	
	// SQL에서 사용할 인덱스 번호 설정 LIMIT은 0부터 시작이다
	public int getPageStart() { 
		return (this.page-1)*perPageNum;
	}
	
	// 디폴트 선언 / 여기서 페이당 보여줄 게시글 갯수를 변경하려면 perPageNum의 값을 바꾸면 된다.
	public Criteria() {
		this.page = 1;
		this.perPageNum = 10;
	}

	public int getPage() {
		return page;
	}
	
	// 페이지 번호가 음수가 되지 않게
	public void setPage(int page) {
		if(page < 0) {
			page = 1;
		} 
		this.page = page;	
	}
	public int getPerPageNum() {
		return perPageNum;
	}
	
	// 페이지당 보여줄 게시글 수를 변하지 않기 위해서 설정
	public void setPerPageNum(int pageCount) {
		int cnt = this.perPageNum;
		if(pageCount != cnt) {
			this.perPageNum = cnt;
		} else {
			this.perPageNum = pageCount;
		}
	}
	
}
