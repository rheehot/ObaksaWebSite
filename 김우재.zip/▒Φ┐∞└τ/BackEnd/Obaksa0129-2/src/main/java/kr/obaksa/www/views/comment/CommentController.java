package kr.obaksa.www.views.comment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.comment.Comment;
import kr.obaksa.www.biz.comment.impl.CommentService;

@RestController
public class CommentController {

	@Autowired
	@Qualifier("commentService")
	private CommentService commentservice;
	
	@Autowired
	@Qualifier("commentServiceMybatis")
	private CommentService commentserviceMybatis;
	
	@RequestMapping(value = "/boards/{comment_board}/comment", method = RequestMethod.GET)
	public String writeCommentError(@PathVariable(value="comment_board") int comment_board, Comment comment) {
		System.out.println("잘못 왔슈");
		String data = "잘못 왔슈";
		return(data);
	}
	
	@RequestMapping(value = "/boards/{comment_board}/comment", method = RequestMethod.POST)
	public String writeComment(@PathVariable(value="comment_board") int comment_board, Comment comment) {
		System.out.println("여기까지 오면 좋겠슈");
		System.out.println(comment.getComment_board());
		System.out.println(comment.getComment_writer());
		System.out.println(comment.getComment_content());
		commentserviceMybatis.insert(comment);
		String data = "잘 왔슈";
		return(data);
	}

}
