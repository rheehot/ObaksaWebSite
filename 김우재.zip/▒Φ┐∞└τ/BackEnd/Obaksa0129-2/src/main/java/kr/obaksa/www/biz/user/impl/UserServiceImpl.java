package kr.obaksa.www.biz.user.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import kr.obaksa.www.biz.user.User;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAOJPA userDAO;

	@Override
	public void insert(User user) {
		userDAO.insert(user);
	}

	@Override
	public void update(User user) {
		userDAO.update(user);
	}

	@Override
	public void delete(User user) {
		userDAO.delete(user);
	}

	@Override
	public User getUser(User user) {
		return userDAO.getUser(user);
	}

	@Override
	public List<User> getUserList(User user) {
		return userDAO.getUserList(user);
	}

}
