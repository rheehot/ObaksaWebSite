package kr.obaksa.www.biz.comment.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.comment.Comment;

@Service("commentService")
public class CommentServiceImpl implements CommentService {

	@Autowired
	CommentDAOJPA commentDAO;

	@Override
	public void insert(Comment comment) {
		commentDAO.insert(comment);
	}

	@Override
	public void update(Comment comment) {
		commentDAO.update(comment);
	}

	@Override
	public void delete(Comment comment) {
		commentDAO.delete(comment);
	}

	@Override
	public Comment getComment(Comment comment) {
		return commentDAO.getComment(comment);
	}

	@Override
	public List<Comment> getCommentList(Comment comment) {
		return commentDAO.getCommentList(comment);
	}

}