package kr.obaksa.www.views.cart;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import kr.obaksa.www.biz.cart.Cart;
import kr.obaksa.www.biz.cart.impl.CartService;
import kr.obaksa.www.biz.product.Product;
import kr.obaksa.www.biz.user.User;

@RestController
public class CartController {
	
	@Autowired
	CartService cartService;
	
	@RequestMapping(value="/cart")
	public ModelAndView getCartList(Product product,  HttpSession session, Cart cart, ModelAndView modelAndView) {
		User user = (User)session.getAttribute("member");
		String user_id = user.getUser_id();
		cart.setCart_product(product.getProduct_id());
		cart.setCart_user(user_id);		
		Map<String, Object> cartMap = new HashMap<String, Object>();
		List<Cart> cartList = cartService.getCartList(cart);
		int sumMoney = cartService.getSumMoney(cart);
		int fee = sumMoney >= 10000 ? 0 : 2500; // 배송비
		cartMap.put("cartList", cartList);
		cartMap.put("count", cartList.size());
		cartMap.put("sumMoney", sumMoney);
		cartMap.put("fee", fee);
		cartMap.put("allSum", sumMoney+fee);
		modelAndView.clear();
		modelAndView.addObject("cartMap",cartMap);
		modelAndView.setViewName("/cart");
		return modelAndView;
	}
	
	@RequestMapping(value="/cart/delete")
	public ModelAndView deleteCart(@RequestParam int cart_id, ModelAndView modelAndView) {
		Cart cart = new Cart();
		cart.setCart_id(cart_id);
		cartService.deleteCart(cart);
		modelAndView.setViewName("/cart");
		return modelAndView;
	}
	
	@RequestMapping(value="/cart/update")
	public ModelAndView updateCart(Cart cart, ModelAndView modelAndView) {
		cartService.updateCart(cart);
		modelAndView.setViewName("/cart");
		return modelAndView;
	}
	
	@RequestMapping(value="/cart/insert")
	public ModelAndView insertCart(Product product, Cart cart,HttpSession session,ModelAndView modelAndView) {
		String user_id = ((User)session.getAttribute("member")).getUser_id();
		cart.setCart_user(user_id);
		cart.setCart_product(product.getProduct_id());
		int count = cartService.getCartCount(cart);
		if(count == 0) {
			System.out.println(cart.toString());
			cartService.insertCart(cart);
		} else {
			System.out.println(cart.toString());
			cartService.modifyCart(cart);
		}
		modelAndView.setViewName("/cart");
		return modelAndView;
	}
	
	
	

}
