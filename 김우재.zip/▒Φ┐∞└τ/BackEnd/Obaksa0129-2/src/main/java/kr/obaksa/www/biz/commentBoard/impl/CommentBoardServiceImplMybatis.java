package kr.obaksa.www.biz.commentBoard.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.obaksa.www.biz.commentBoard.CommentBoard;

@Service("commentBoardServiceMybatis")
public class CommentBoardServiceImplMybatis implements CommentBoardService{

	@Autowired
	private CommentBoardDAOMybatis commentBoardDAO;

	@Override
	public int getCommentBoardCount(CommentBoard commentBoard) {
		return commentBoardDAO.getCommentBoardCount(commentBoard);
	}

	@Override
	public List<CommentBoard> getCommentBoardList(CommentBoard commentBoard) {
		List<CommentBoard> commentList = null;
		commentList =  commentBoardDAO.getCommentBoardList(commentBoard);
		if(commentList != null) {
			System.out.println("디버깅이 되었으면 좋겠어");
		}
		return commentList;
	}

}
