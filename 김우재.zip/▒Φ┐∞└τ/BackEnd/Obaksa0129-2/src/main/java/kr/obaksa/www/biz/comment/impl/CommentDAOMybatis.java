package kr.obaksa.www.biz.comment.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.obaksa.www.biz.comment.Comment;

@Repository
public class CommentDAOMybatis{
	
	@Autowired
	private SqlSessionTemplate mybatis;

	public void insertComment(Comment comment) {
		System.out.println("===> Mybatis�� insertComment() ��� ó��");
		mybatis.insert("CommentDAO.insertComment", comment);
	}

	public void updateComment(Comment comment) {
		System.out.println("===> Mybatis�� updateComment() ��� ó��");
		mybatis.update("CommentDAO.updateComment", comment);
	}

	public void deleteComment(Comment comment) {
		System.out.println("===> Mybatis�� deleteComment() ��� ó��");
		mybatis.delete("CommentDAO.deleteComment", comment);
	}

	public Comment getComment(Comment comment) {
		System.out.println("===> Mybatis�� getComment() ��� ó��");
		return (Comment) mybatis.selectOne("CommentDAO.getComment", comment);
	}

	public List<Comment> getCommentList(Comment comment) {
		System.out.println("===> Mybatis�� getCommentList() ��� ó��");
		return mybatis.selectList("CommentDAO.getCommentList", comment);
	}

}