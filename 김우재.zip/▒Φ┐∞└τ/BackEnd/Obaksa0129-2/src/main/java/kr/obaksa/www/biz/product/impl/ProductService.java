package kr.obaksa.www.biz.product.impl;

import java.util.List;

import kr.obaksa.www.biz.product.Product;

public interface ProductService {

	void insertProduct(Product product);

	void updateProduct(Product product);

	void deleteProduct(Product product);

	Product getProduct(Product product);

	List<Product> getProductList(Product product);

}