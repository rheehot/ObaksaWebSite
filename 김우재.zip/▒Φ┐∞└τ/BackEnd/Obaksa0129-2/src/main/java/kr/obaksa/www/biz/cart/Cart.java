package kr.obaksa.www.biz.cart;

public class Cart {
	private int cart_id;
	private String cart_user;
	private int cart_product;
	private int cart_amount;
	private String user_name;
	private String product_name;
	private String product_price;
	private int money;
	
	
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public String getCart_user() {
		return cart_user;
	}
	public void setCart_user(String cart_user) {
		this.cart_user = cart_user;
	}
	public int getCart_product() {
		return cart_product;
	}
	public void setCart_product(int cart_product) {
		this.cart_product = cart_product;
	}
	public int getCart_amount() {
		return cart_amount;
	}
	public void setCart_amount(int cart_amount) {
		this.cart_amount = cart_amount;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getProduct_price() {
		return product_price;
	}
	public void setProduct_price(String product_price) {
		this.product_price = product_price;
	}
	
	@Override
	public String toString() {
		return "cart_id : "+cart_id+"cart_user : "+cart_user+"cart_product : "+cart_product+"cart_amount : "+cart_amount ;
	}
	
}
