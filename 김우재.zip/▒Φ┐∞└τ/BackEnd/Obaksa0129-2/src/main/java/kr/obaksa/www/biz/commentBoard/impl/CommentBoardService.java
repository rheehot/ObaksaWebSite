package kr.obaksa.www.biz.commentBoard.impl;

import java.util.List;

import kr.obaksa.www.biz.commentBoard.CommentBoard;

public interface CommentBoardService {

	int getCommentBoardCount(CommentBoard commentBoard);

	List<CommentBoard> getCommentBoardList(CommentBoard commentBoard);

}