package kr.obaksa.www.views.board;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.board.Criteria;
import kr.obaksa.www.biz.board.PageMaker;
import kr.obaksa.www.biz.board.impl.BoardService;
import kr.obaksa.www.biz.commentBoard.impl.CommentBoardService;

@RestController
@SessionAttributes("board")
public class BoardController {

	@Autowired
	@Qualifier("boardService")
	private BoardService boardservice;

	@Autowired
	@Qualifier("boardServiceMybatis")
	private BoardService boardserviceMybatis;
	
	
	@Autowired
	@Qualifier("commentBoardServiceMybatis")
	private CommentBoardService commentBoardserviceMybatis;

	@RequestMapping(value = "/boards")
	public ModelAndView getBoardList(Criteria cri, ModelAndView modelAndView) throws Exception{
		PageMaker pageMaker = new PageMaker(cri);
		int totalCount = boardserviceMybatis.getBoardCount();
		pageMaker.setTotalCount(totalCount);
		
		List<Board> boardList = boardserviceMybatis.listAll(cri);
		modelAndView.addObject("boardList", boardList);
		modelAndView.addObject("pageMaker", pageMaker);
		modelAndView.setViewName("/boards");
		return modelAndView;
	}

	@RequestMapping(value = "/boards/{board_seq}", method = RequestMethod.POST)
	public ModelAndView postBoard(@PathVariable(value = "board_seq") int board_seq, Board board,
			ModelAndView modelAndView) {
		System.out.println("1번");
		board = boardservice.getBoard(board);
		board.setBoard_cnt(board.getBoard_cnt() + 1);
		boardservice.updateBoard(board);
		board = boardservice.getBoard(board);
		modelAndView.addObject("board", board);
		modelAndView.setViewName("/boards/board");
		return modelAndView;
	}
	
	@RequestMapping(value = "/boards/{board_seq}", method = RequestMethod.GET)
	public ModelAndView getBoard(@PathVariable(value = "board_seq") int board_seq, Board board,
			ModelAndView modelAndView) {
		board = boardservice.getBoard(board);
		board.setBoard_cnt(board.getBoard_cnt() + 1);
		boardservice.updateBoard(board);
		board = boardservice.getBoard(board);
		modelAndView.addObject("board", board);
		modelAndView.setViewName("/boards/board");
		return modelAndView;
	}

	@RequestMapping(value = "/boards/write", method = RequestMethod.GET)
	public ModelAndView writeBoard(ModelAndView modelAndView) {
		modelAndView.clear();
		modelAndView.setViewName("/boards/write");
		return modelAndView;
	}

	@RequestMapping(value = "/boards/write", method = RequestMethod.POST)
	public ModelAndView write(Board board, ModelAndView modelAndView) {
		System.out.println("게시글 입력중");
		boardserviceMybatis.insertBoard(board);
		modelAndView.setViewName("redirect:/boards");
		return modelAndView;
	}

	@RequestMapping(value = "/boards/{board_seq}/edit", method = RequestMethod.GET)
	public ModelAndView editBoard(@PathVariable(value = "board_seq") int board_seq, Board board, ModelAndView modelAndView) {
		modelAndView.setViewName("/boards/board/edit");
		return modelAndView;
	}

	@RequestMapping(value = "/boards/{board_seq}/edit", method = RequestMethod.POST)
	public ModelAndView edit(@PathVariable(value = "board_seq") int board_seq, Board board, ModelAndView modelAndView) {
		boardservice.updateBoard(board);
		modelAndView.setViewName("redirect:/boards");
		return modelAndView;
	}

	@RequestMapping(value = "/boards/{board_seq}/delete", method = RequestMethod.GET)
	public ModelAndView deleteError(@PathVariable(value="board_seq") int board_seq, Board board, ModelAndView modelAndView) {
		modelAndView.setViewName("redirect:/boards");
		return modelAndView;
	}
	
	@RequestMapping(value = "/boards/{board_seq}/delete", method = RequestMethod.POST)
	public ModelAndView delete(@PathVariable(value="board_seq") int board_seq, Board board, ModelAndView modelAndView) {
		System.out.println("여기가 되는지");
		boardservice.deleteBoard(board);
		modelAndView.setViewName("redirect:/boards");
		return modelAndView;
	}
}

/*
 * // 湲� �벑濡�
 * 
 * @RequestMapping(value = "/board/insert", method = RequestMethod.GET) public
 * String boardPage(Board board) throws IOException{ board.getBoard_seq();
 * boardservice.insertBoard(board); return "board/"; // return
 * "getBoardList.do"; }
 * 
 * // 湲� �닔�젙
 * 
 * @RequestMapping(value = "/updateBoard.do") public String
 * updateBoard(@ModelAttribute("board") Board board) {
 * boardservice.updateBoard(board); return "getBoardList.do"; // return
 * "getBoardList.do"; }
 * 
 * // 湲� �궘�젣
 * 
 * @RequestMapping(value = "/deleteBoard.do") public String deleteBoard(Board
 * board) {
 * 
 * boardservice.deleteBoard(board); return "getBoardList.do";// return
 * "getBoardList.do"; }
 * 
 * // 寃��깋 議곌굔 紐⑸줉 �꽕�젙
 * 
 * @ModelAttribute("conditionMap") public Map<String, String>
 * searchConditionMap() { Map<String, String> conditionMap = new HashMap<String,
 * String>(); conditionMap.put("�젣紐�", "TITLE"); conditionMap.put("�궡�슜",
 * "CONTENT"); return conditionMap; }
 */
