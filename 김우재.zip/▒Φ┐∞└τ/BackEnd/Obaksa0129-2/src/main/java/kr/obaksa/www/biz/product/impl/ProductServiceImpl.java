package kr.obaksa.www.biz.product.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.obaksa.www.biz.product.Product;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductDAO productDAO;
	
	@Override
	public void insertProduct(Product product) {
		productDAO.insertProduct(product);
	}

	@Override
	public void updateProduct(Product product) {
		productDAO.updateProduct(product);
	}

	@Override
	public void deleteProduct(Product product) {
		productDAO.deleteProduct(product);
	}

	@Override
	public Product getProduct(Product product) {
		return productDAO.getProduct(product);
	}

	@Override
	public List<Product> getProductList(Product product) {
		return productDAO.getProductList(product);
	}

}
