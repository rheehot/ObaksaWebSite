package kr.obaksa.www.biz.product.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.obaksa.www.biz.product.Product;

@Repository
public class ProductDAO {

	@Autowired
	SqlSessionTemplate mybatis;

	public void insertProduct(Product product) {
		System.out.println("===> Mybatis�� insertProduct() ��� ó��");
		mybatis.insert("ProductDAO.insertProduct", product);
	}

	public void updateProduct(Product product) {
		System.out.println("===> Mybatis�� updateProduct() ��� ó��");
		mybatis.update("ProductDAO.updateProduct", product);
	}

	public void deleteProduct(Product product) {
		System.out.println("===> Mybatis�� deleteProduct() ��� ó��");
		mybatis.delete("ProductDAO.deleteProduct", product);
	}

	public Product getProduct(Product product) {
		System.out.println("===> Mybatis�� getProduct() ��� ó��");
		return (Product) mybatis.selectOne("ProductDAO.getProduct", product);
	}

	public List<Product> getProductList(Product product) {
		System.out.println("===> Mybatis�� getProductList() ��� ó��");
		return mybatis.selectList("ProductDAO.getProductList", product);
	}

	
}
