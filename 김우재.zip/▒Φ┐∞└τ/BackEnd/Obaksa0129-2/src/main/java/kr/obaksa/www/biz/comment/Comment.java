package kr.obaksa.www.biz.comment;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "comment")
public class Comment implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int comment_seq;
	
	private int comment_board;
	private String comment_writer;
	private String comment_content;
	private Date comment_regdate;
	private int comment_available;
	
	
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Comment() {}
	
	public Comment(int comment_seq, int comment_board, String comment_writer, String comment_content,
			Date comment_regdate, int comment_available) {
		super();
		this.comment_seq = comment_seq;
		this.comment_board = comment_board;
		this.comment_writer = comment_writer;
		this.comment_content = comment_content;
		this.comment_regdate = comment_regdate;
		this.comment_available = comment_available;
	}

	public int getComment_seq() {
		return comment_seq;
	}

	public void setComment_seq(int comment_seq) {
		this.comment_seq = comment_seq;
	}

	public int getComment_board() {
		return comment_board;
	}

	public void setComment_board(int comment_board) {
		this.comment_board = comment_board;
	}

	public String getComment_writer() {
		return comment_writer;
	}

	public void setComment_writer(String comment_writer) {
		this.comment_writer = comment_writer;
	}

	public String getComment_content() {
		return comment_content;
	}

	public void setComment_content(String comment_content) {
		this.comment_content = comment_content;
	}

	public Date getComment_regdate() {
		return comment_regdate;
	}

	public void setComment_regdate(Date comment_regdate) {
		this.comment_regdate = comment_regdate;
	}

	public int getComment_available() {
		return comment_available;
	}

	public void setComment_available(int comment_available) {
		this.comment_available = comment_available;
	}


}
