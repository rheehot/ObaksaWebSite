package kr.obaksa.www.biz.comment.impl;

import java.util.List;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.comment.Comment;

public interface CommentService {

	void insert(Comment comment);

	void update(Comment comment);

	void delete(Comment comment);

	Comment getComment(Comment comment);

	List<Comment> getCommentList(Comment comment);

}