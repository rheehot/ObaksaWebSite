package kr.obaksa.www.biz.commentBoard.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.obaksa.www.biz.commentBoard.CommentBoard;

@Repository
public class CommentBoardDAOMybatis {
	
	@Autowired
	private SqlSessionTemplate mybatis;

	public int getCommentBoardCount(CommentBoard commentBoard) {
		return mybatis.selectOne("CommentBoardDAO.getCommentBoardCount", commentBoard);
	}

	public List<CommentBoard> getCommentBoardList(CommentBoard commentBoard) {
		System.out.println("===> Mybatis�� getCommentBoardList() ��� ó��");
		System.out.println(commentBoard.getBoard_seq());
		List<CommentBoard> commentList;
		commentList = mybatis.selectList("CommentBoardDAO.getCommentBoardList", commentBoard);
		if(commentList != null) {
			System.out.println("디버깅이 되었으면 좋겠어");
		}
		for (CommentBoard commentBoard2 : commentList) {
			System.out.println("sad"+commentBoard2.getBoard_seq());
			System.out.println("asd"+commentBoard2.getBoard_title());
			System.out.println("asd"+commentBoard2.getBoard_writer());
		}
		System.out.println("여기가 성공 되었으면");
		return commentList;
	}
}