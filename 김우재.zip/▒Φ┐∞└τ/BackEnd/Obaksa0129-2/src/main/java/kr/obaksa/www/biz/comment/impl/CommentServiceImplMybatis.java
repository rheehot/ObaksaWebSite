package kr.obaksa.www.biz.comment.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.obaksa.www.biz.comment.Comment;

@Service("commentServiceMybatis")
public class CommentServiceImplMybatis implements CommentService {

	@Autowired
	private CommentDAOMybatis commentDAO;

	public void insert(Comment comment) {
		commentDAO.insertComment(comment); 
	}

	public void update(Comment comment) {
		commentDAO.updateComment(comment);
	}

	public void delete(Comment comment) {
		commentDAO.deleteComment(comment);
	}

	public Comment getComment(Comment comment) {
		return commentDAO.getComment(comment);
	}

	public List<Comment> getCommentList(Comment comment) {
		return commentDAO.getCommentList(comment);
	}

}
