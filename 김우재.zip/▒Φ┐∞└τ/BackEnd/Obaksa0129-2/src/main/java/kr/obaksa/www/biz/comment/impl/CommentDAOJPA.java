package kr.obaksa.www.biz.comment.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.comment.Comment;

@Repository
public class CommentDAOJPA {
	@PersistenceContext
	private EntityManager entityManager;

	public void insert(Comment comment) {
		entityManager.persist(comment);
	}

	public void update(Comment comment) {
		entityManager.merge(comment);
	}

	public void delete(Comment comment) {
		entityManager.remove(entityManager.find(Comment.class, comment.getComment_seq()));
	}

	public Comment getComment(Comment comment) {
		System.out.println("댓글 번호 : " + comment.getComment_seq());
		return (Comment) entityManager.find(Comment.class, comment.getComment_seq());
	}

	public List<Comment> getCommentList(Comment comment) {
		return entityManager.createQuery("from Comment c order by c.comment_seq desc").getResultList();
	}
}
