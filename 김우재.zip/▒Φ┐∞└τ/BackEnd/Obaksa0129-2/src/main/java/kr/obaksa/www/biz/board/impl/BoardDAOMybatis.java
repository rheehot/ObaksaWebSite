package kr.obaksa.www.biz.board.impl;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.obaksa.www.biz.board.Board;
import kr.obaksa.www.biz.board.Criteria;

@Repository
public class BoardDAOMybatis{
	
	@Autowired
	private SqlSessionTemplate mybatis;

	public void insertBoard(Board board) {
		System.out.println("===> Mybatis�� insertBoard() ��� ó��");
		mybatis.insert("BoardDAO.insertBoard", board);
	}

	public void updateBoard(Board board) {
		System.out.println("===> Mybatis�� updateBoard() ��� ó��");
		mybatis.update("BoardDAO.updateBoard", board);
	}

	public void deleteBoard(Board board) {
		System.out.println("===> Mybatis�� deleteBoard() ��� ó��");
		mybatis.delete("BoardDAO.deleteBoard", board);
	}

	public Board getBoard(Board board) {
		System.out.println("===> Mybatis�� getBoard() ��� ó��");
		return (Board) mybatis.selectOne("BoardDAO.getBoard", board);
	}

	public List<Board> getBoardList(Board board) {
		System.out.println("===> Mybatis�� getBoardList() ��� ó��");
		return mybatis.selectList("BoardDAO.getBoardList", board);
	}

	@SuppressWarnings("unchecked")
	public List<Board> listAll(Criteria cri){
		return mybatis.selectList("BoardDAO.listAll",cri);
	}
	
	public int getBoardCount() {
		return mybatis.selectOne("BoardDAO.getBoardCount");
	}
	
}