package com.springbook.biz.common;

import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionException;
import org.springframework.transaction.TransactionStatus;

public class PlatformTransactionManager {
	TransactionStatus getTransaction(TransactionDefinition definition) throws TransactionException{
		
	}
}
