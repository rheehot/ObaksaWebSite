package com.springbook.view.controller;

import java.util.HashMap;
import java.util.Map;

import com.springbook.view.board.DeleteBoardController;
import com.springbook.view.board.GetBoardController;
import com.springbook.view.board.GetBoardListController;
import com.springbook.view.board.InsertBoardController;
import com.springbook.view.board.UpdateBoardController;
import com.springbook.view.user.LoginController;
import com.springbook.view.user.LogoutController;

public class HandlerMapping {
	private Map<String, Controller> mappngs;
	
	public HandlerMapping() {
		mappngs = new HashMap<String, Controller>();
		mappngs.put("/login.do", new LoginController());
		mappngs.put("/getBoardList.do", new GetBoardListController());		
		mappngs.put("/getBoard.do", new GetBoardController());		
		mappngs.put("/insertBoard.do", new InsertBoardController());		
		mappngs.put("/updateBoard.do", new UpdateBoardController());		
		mappngs.put("/deleteBoard.do", new DeleteBoardController());		
		mappngs.put("/logout.do", new LogoutController());		
	}
	
	public Controller getController(String path) {
		return mappngs.get(path);
	}

}
